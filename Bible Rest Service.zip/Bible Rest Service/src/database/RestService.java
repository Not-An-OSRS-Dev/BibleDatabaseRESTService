package database;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import bible.Verse;

@RequestScoped
@Path("/search")
@Produces({ "application/xml", "application/json" })
@Consumes({ "application/xml", "application/json" })
public class RestService 
{
	@Inject
	DatabaseConnect service;
	
	@GET
	@Path("/findCount/{word}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Verse> numInstances(@PathParam("word") String word)
	{
		List<Verse> verses = service.numOccurancesOf(word);
		return verses;
	}
	
	public void setService(DatabaseConnect service)
	{
		this.service = service;
		
	}
	
	public DatabaseConnect getService()
	{
		return this.service;
	}

}
