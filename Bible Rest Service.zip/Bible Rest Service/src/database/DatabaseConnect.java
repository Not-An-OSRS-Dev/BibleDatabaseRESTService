package database;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import bible.Verse;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

@Local(DatabaseInterface.class)
@Stateless
@LocalBean
@Alternative
public class DatabaseConnect implements DatabaseInterface{
	
	public DatabaseConnect()
	{
		
	}
	
	private Connection getConnection()
	{
		Connection conn = null;
		String url= "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "root";
		
		try {
			conn = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Connection made");
		if (conn == null)
		{
			System.out.println("Connection is null");
		}
		return conn;
	}
	
	//Give a word, and the db will query how many times that word exists
	public List<Verse> numOccurancesOf(String word)
	{
		Connection conn = this.getConnection();
		String sql = "SELECT * FROM public.t_asv WHERE line LIKE '%" + word + "%'";
		Statement stmt;
		List<Verse> verses = new ArrayList<Verse>();
		try {
			System.out.println("Statement and Connection created");
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next())
			{
				int id = rs.getInt("id");
				int book = rs.getInt("b");
				int chapter = rs.getInt("c");
				int verse = rs.getInt("v");
				String text = rs.getString("line");
				Verse item = new Verse(id, book, chapter, verse, text);
				verses.add(item);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return verses;
	}

}
