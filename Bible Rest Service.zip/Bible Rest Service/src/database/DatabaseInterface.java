package database;

import javax.ejb.Local;

@Local
public interface DatabaseInterface {

}
