package controller;

import database.DatabaseConnect;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.inject.Inject;

@ManagedBean
@ViewScoped
public class Controller {
	
	@Inject
	public DatabaseConnect service;
	
	public Controller()
	{
		
	}
	
	public String onSubmit()
	{
		return "TestResponse.xhtml";
	}

	public void setService(DatabaseConnect service)
	{
		this.service = service;
	}
	
	public DatabaseConnect getService()
	{
		return service;
	}
}
