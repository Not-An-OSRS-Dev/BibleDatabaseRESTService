package bible;

public class Verse 
{
	private int id;
	private int book;
	private int chapter;
	private int verse;
	private String text;
	
	public Verse(int id, int book, int chapter, int verse, String text)
	{
		this.id = id;
		this.book = book;
		this.chapter = chapter;
		this.verse = verse;
		this.text = text;
	}
	
	public Verse()
	{
		this.id = 0;
		this.book = 0;
		this.chapter = 0;
		this.verse = 0;
		this.text = "";
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the book
	 */
	public int getBook() {
		return book;
	}

	/**
	 * @param book the book to set
	 */
	public void setBook(int book) {
		this.book = book;
	}

	/**
	 * @return the chapter
	 */
	public int getChapter() {
		return chapter;
	}

	/**
	 * @param chapter the chapter to set
	 */
	public void setChapter(int chapter) {
		this.chapter = chapter;
	}

	/**
	 * @return the verse
	 */
	public int getVerse() {
		return verse;
	}

	/**
	 * @param verse the verse to set
	 */
	public void setVerse(int verse) {
		this.verse = verse;
	}

	/**
	 * @return the text
	 */
	public String getText() {
		return text;
	}

	/**
	 * @param text the text to set
	 */
	public void setText(String text) {
		this.text = text;
	}
	
	
}
